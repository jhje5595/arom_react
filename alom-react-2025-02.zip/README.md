# 아롬 리액트팀 2주차 과제

### Prerequisites
- node (18+)
- npm

### How to run
- npm i
- npm start